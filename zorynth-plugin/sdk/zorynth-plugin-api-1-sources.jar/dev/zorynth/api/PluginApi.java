package dev.zorynth.api;

import java.nio.file.Path;
import java.util.List;

public final class PluginApi {
    public static final int VERSION = 1;
    public static final int UI_VERSION = 2;
    private PluginApi() {}

    public interface Plugin {
        void onLoad(Context context) throws Exception;
        default void onShutdown() throws Exception {}
    }
    public interface Context {
        String pluginId();
        Path dataDirectory();
        ClientView client();
        void notify(String message);
        ModuleHandle module(ModuleSpec spec, Module callbacks);
        void hud(HudSpec spec, Hud renderer);
        void ui(String id, String toggleModule, Layer layer, int priority, Ui callbacks);
        void theme(String toggleModule, int priority, Theme theme);
        void decorateHud(String elementId, String toggleModule, int priority, HudTransform transform);
        default int uiVersion() { return 1; }
        default UiHost uiHost() { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void replaceScreen(String id, String toggleModule, ScreenTarget target, int priority, Ui callbacks) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void screen(String id, String title, Ui callbacks) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void overlay(String id, String toggleModule, int priority, boolean replaceHud, Ui callbacks) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void overlay(String id, String toggleModule, int priority, HudPolicy policy, Ui callbacks) { overlay(id, toggleModule, priority, policy != HudPolicy.ADD, callbacks); }
    }
    public enum ScreenTarget { MODULES, HUD_EDITOR }
    public enum HudPolicy { ADD, REPLACE_CLIENT, REPLACE_ALL }
    public enum SettingKind { BOOLEAN, NUMBER, CHOICE, TEXT, COLOR, KEY, BLOCK_LIST }
    public enum Category { CLIENT, RENDER, COMBAT, MOVEMENT, PLAYER }
    public enum Layer { BACKGROUND, FOREGROUND }
    public enum ColorRole { ACCENT, TEXT, MUTED }
    public enum InputKind { CLICK, RELEASE, DRAG, SCROLL, KEY, CHARACTER, KEY_RELEASE, MOVE }
    public record ModuleSpec(String id, String name, Category category, boolean enabledByDefault) {}
    public record HudSpec(String id, String name, boolean enabledByDefault, double x, double y, int width, int height) {}
    public record Theme(int accent, int text, int muted) {}
    public record ClientView(boolean connected, String playerName, double x, double y, double z,
                             float yaw, float pitch, float health, float absorption, int fps, int ping, double speed) {
        public static final ClientView EMPTY = new ClientView(false, "", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
    public record UiView(String screen, int width, int height, double mouseX, double mouseY, float partialTick, ClientView client) {}
    public record InputEvent(InputKind kind, double x, double y, int button, int key, int modifiers, String text, double deltaX, double deltaY) {}
    public interface Value<T> {
        T get();
        void set(T value);
    }
    public interface ModuleHandle {
        String id();
        boolean enabled();
        void setEnabled(boolean enabled);
        Value<Boolean> bool(String id, String name, boolean value);
        Value<Double> number(String id, String name, double value, double min, double max, double step);
        Value<String> choice(String id, String name, String value, String... choices);
        Value<String> text(String id, String name, String value, int maximum);
        Value<Integer> color(String id, String name, int argb);
    }
    public interface Module {
        default void onEnable() throws Exception {}
        default void onDisable() throws Exception {}
        default void tick(ClientView client) throws Exception {}
        default void onDisconnect() throws Exception {}
        default String displayData() throws Exception { return ""; }
    }
    public interface Canvas {
        int width();
        int height();
        int textWidth(String text);
        void fill(int x, int y, int width, int height, int argb);
        void text(String text, int x, int y, int argb, boolean shadow);
        default void push() { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void pop() { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void translate(double x, double y) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void scale(double x, double y) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void rotate(double degrees) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void clip(int x, int y, int width, int height) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void unclip() { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void gradient(int x, int y, int width, int height, int start, int end, boolean horizontal) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void roundedRect(int x, int y, int width, int height, double radius, int argb) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void line(double x1, double y1, double x2, double y2, double thickness, int argb) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void circle(double x, double y, double radius, int argb) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void polygon(double[] coordinates, int argb) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void image(String texture, int x, int y, int width, int height, float u0, float v0, float u1, float v1) { throw new UnsupportedOperationException("UI extension unavailable"); }
        default void text(String font, String text, int x, int y, int argb, boolean shadow) { text(text, x, y, argb, shadow); }
        default int textWidth(String font, String text) { return textWidth(text); }
        default Object nativeHandle(String name) { return null; }
    }
    public record SettingInfo(String id, String name, String page, SettingKind kind, double min, double max, double step, int maximum, List<String> choices) {
        public SettingInfo { choices = List.copyOf(choices); }
    }
    public interface SettingControl extends Value<Object> {
        SettingInfo info();
        boolean visible();
    }
    public interface ModuleControl {
        String id();
        String name();
        String category();
        boolean enabled();
        boolean alwaysOn();
        void setEnabled(boolean enabled);
        int bindKey();
        String bindMode();
        void bind(int key, String mode);
        List<SettingControl> settings();
    }
    public interface UiHost {
        List<ModuleControl> modules();
        void save();
        void open(String screenId);
        void close();
        String clipboard();
        void clipboard(String text);
        String image(String resource) throws Exception;
        Object nativeHandle(String name);
    }
    @FunctionalInterface public interface Hud {
        void render(Canvas canvas, ClientView client, boolean editing) throws Exception;
    }
    public interface Ui {
        default void render(Canvas canvas, UiView view) throws Exception {}
        default boolean input(UiView view, InputEvent event) throws Exception { return false; }
        default void opened(UiView view) throws Exception {}
        default void resized(UiView view) throws Exception {}
        default void closed() throws Exception {}
    }
    @FunctionalInterface public interface HudTransform {
        List<String> lines(ClientView client, List<String> original) throws Exception;
    }
}
